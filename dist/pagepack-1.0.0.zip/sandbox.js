const chunks = [];
let pageScriptErrors = 0;

function isExpectedOfflineScriptError(value) {
  const message = String(value?.message || value?.reason?.message || value?.reason || value || "");
  return /sandboxed and lacks the 'allow-same-origin' flag|Invalid relative url or base scheme isn't hierarchical/i.test(message);
}

window.addEventListener("error", (event) => {
  if (isExpectedOfflineScriptError(event)) {
    event.preventDefault?.();
    return;
  }
  pageScriptErrors += 1;
});
window.addEventListener("unhandledrejection", (event) => {
  if (isExpectedOfflineScriptError(event)) {
    event.preventDefault?.();
    return;
  }
  pageScriptErrors += 1;
});

function reportRendered(phase) {
  const body = document.body;
  const text = String(body?.innerText || "").replace(/\s+/g, " ").trim();
  const mediaCount = body?.querySelectorAll?.("img,svg,canvas,video,audio,object,embed")?.length || 0;
  window.parent.postMessage({
    source: "pagepack-sandbox",
    type: "rendered",
    phase,
    hasContent: text.length > 0 || mediaCount > 0,
    textLength: text.length,
    mediaCount,
    scriptErrors: pageScriptErrors,
  }, "*");
}

window.addEventListener("message", (event) => {
  const message = event.data;
  if (!message || message.source !== "pagepack-viewer") return;
  if (message.type === "load-start") {
    chunks.length = 0;
    return;
  }
  if (message.type === "load-chunk") {
    chunks.push(String(message.chunk || ""));
    return;
  }
  if (message.type === "load-end") {
    const html = chunks.join("");
    try {
      document.open();
      document.write(html);
      document.close();
    } catch {
      window.parent.postMessage({ source: "pagepack-sandbox", type: "rendered", phase: "settled", hasContent: false, textLength: 0, mediaCount: 0, scriptErrors: pageScriptErrors + 1 }, "*");
      return;
    }
    setTimeout(() => reportRendered("initial"), 250);
    setTimeout(() => reportRendered("settled"), 1500);
  }
});

window.parent.postMessage({ source: "pagepack-sandbox", type: "ready" }, "*");
